// Name: Sreyas Kotha
// Roll No: 2301CS53
#include <iostream>
using namespace std;

extern "C" void yylex();

int main() {
  yylex(); 
  return 0;
}
