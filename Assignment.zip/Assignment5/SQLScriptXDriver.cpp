// SQLScriptXDriver.cpp
// Name: Shreyas Kumar Jaiswal
// Roll No: 2301CS52
// CS3104 Compiler Lab, Autumn 2025 - Assignment 5
#include <iostream>
using namespace std;

extern "C" void run_lexer();

int main() {
  run_lexer(); 
  return 0;
}
